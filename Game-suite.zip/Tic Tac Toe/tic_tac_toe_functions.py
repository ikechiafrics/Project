
def printBoard(board):
    # print(board['7'] + '|' + board['8'] + '|' + board['9'])
    # print('-+-+-')
    # print(board['4'] + '|' + board['5'] + '|' + board['6'])
    # print('-+-+-')
    # print(board['1'] + '|' + board['2'] + '|' + board['3'])

    big_arr = []
    arr = []

    for num in range(1,4):
        arr.append(board[str(num)])

    big_arr.insert(0,arr)

    arr = []

    for num in range(4,7):
        arr.append(board[str(num)])

    big_arr.insert(0,arr)
    
    arr = []

    for num in range(7,10):
        arr.append(board[str(num)])

    big_arr.insert(0,arr)

    for row in big_arr:
        print(row)